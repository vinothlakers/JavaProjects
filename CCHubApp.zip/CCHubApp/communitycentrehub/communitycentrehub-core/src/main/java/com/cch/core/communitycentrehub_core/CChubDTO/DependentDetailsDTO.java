package com.cch.core.communitycentrehub_core.CChubDTO;



import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class DependentDetailsDTO {
   
    private FlatDetailsDTO flatInfo;
    private String relation;
    private String dependentName;
    private int age;

    

   

}
