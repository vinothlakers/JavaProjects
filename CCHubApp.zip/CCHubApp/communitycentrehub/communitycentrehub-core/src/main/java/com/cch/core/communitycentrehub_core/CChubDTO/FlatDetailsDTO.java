package com.cch.core.communitycentrehub_core.CChubDTO;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class FlatDetailsDTO {
    private String flatNo;
    private String blockNme;
}
