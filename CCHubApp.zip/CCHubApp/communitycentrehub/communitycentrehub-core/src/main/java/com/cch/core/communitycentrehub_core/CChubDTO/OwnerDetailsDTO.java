package com.cch.core.communitycentrehub_core.CChubDTO;

import java.util.List;


import lombok.Getter;
import lombok.Setter;


public class OwnerDetailsDTO {
 
    public FlatDetailsDTO flatInfo;

    private String ownerName;
    private String ownerContactNo;
    private String email;
    private boolean flatstay;
    private int noOfDependent;
    private String bloodGroup;
    
  
    private List<DependentDetailsDTO> dependentDetails;

    
    private List<VehicleDetailsDTO> vehiclesDetails;

    
}
