package com.cch.core.communitycentrehub_core.CCHubService;

import com.cch.core.communitycentrehub_core.CChubDTO.OwnerDetailsDTO;

public interface CCHubOwnerService{
    public String submitownerdetails(OwnerDetailsDTO ownerdetails);

     
    
}
