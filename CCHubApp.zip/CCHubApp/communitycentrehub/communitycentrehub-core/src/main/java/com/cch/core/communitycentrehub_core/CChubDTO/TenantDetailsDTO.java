package com.cch.core.communitycentrehub_core.CChubDTO;

import java.util.List;



import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class TenantDetailsDTO {
   
   private FlatDetailsDTO flatInfo;
   private String tenantName;
   private String tenantContactNo;
   private String email;
   private int noOfDependent;
    private  String bloodGroup;

    
    private List<DependentDetailsDTO> dependentDetails;

   
    private List<VehicleDetailsDTO> vehiclesDetails;
}
