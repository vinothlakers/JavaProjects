package com.cch.core.communitycentrehub_core.CCHubService;

public interface CChubTenantService {
    
}
