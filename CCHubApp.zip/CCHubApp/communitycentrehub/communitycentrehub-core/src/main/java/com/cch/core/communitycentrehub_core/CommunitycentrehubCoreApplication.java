package com.cch.core.communitycentrehub_core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunitycentrehubCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunitycentrehubCoreApplication.class, args);
	}

}
