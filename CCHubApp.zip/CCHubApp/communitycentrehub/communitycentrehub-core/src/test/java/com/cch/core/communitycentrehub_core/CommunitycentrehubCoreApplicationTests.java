package com.cch.core.communitycentrehub_core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommunitycentrehubCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
