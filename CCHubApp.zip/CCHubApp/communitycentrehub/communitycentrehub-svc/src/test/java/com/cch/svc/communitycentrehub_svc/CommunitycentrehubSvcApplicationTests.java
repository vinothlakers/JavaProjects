package com.cch.svc.communitycentrehub_svc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommunitycentrehubSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
