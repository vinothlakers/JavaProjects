package com.cch.svc.communitycentrehub_svc.CCHubServiceImpl;

import org.springframework.stereotype.Service;

import com.cch.core.communitycentrehub_core.CCHubService.CCHubOwnerService;

import com.cch.core.communitycentrehub_core.CChubDTO.OwnerDetailsDTO;

@Service
public class CCHubOwnerServiceImpl implements CCHubOwnerService{

    
@Override
    public String submitownerdetails(OwnerDetailsDTO ownerdetails) {
        
        return "Owner detsils Successfully submitted";
    }
}