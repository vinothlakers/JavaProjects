package com.cch.svc.communitycentrehub_svc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunitycentrehubSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunitycentrehubSvcApplication.class, args);
	}

}
