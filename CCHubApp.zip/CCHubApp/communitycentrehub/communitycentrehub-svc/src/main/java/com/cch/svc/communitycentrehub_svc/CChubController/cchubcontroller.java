package com.cch.svc.communitycentrehub_svc.CChubController;

import org.springframework.web.bind.annotation.RestController;

import com.cch.core.communitycentrehub_core.CCHubService.CCHubOwnerService;
import com.cch.core.communitycentrehub_core.CChubDTO.OwnerDetailsDTO;
import com.cch.svc.communitycentrehub_svc.CCHubServiceImpl.CCHubOwnerServiceImpl;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class cchubcontroller {

  private final CCHubOwnerService ownerserv;

  private cchubcontroller(CCHubOwnerServiceImpl ownerserv)
  {
    this.ownerserv = ownerserv;
  }

  @PostMapping("/ownerdetails")
  public String postMethodName(@RequestBody OwnerDetailsDTO ownerdetails) {
    return ownerserv.submitownerdetails(ownerdetails);
  }
  


    
}
