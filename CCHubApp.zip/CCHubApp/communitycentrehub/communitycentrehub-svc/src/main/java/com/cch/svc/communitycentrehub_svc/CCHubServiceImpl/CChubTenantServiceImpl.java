package com.cch.svc.communitycentrehub_svc.CCHubServiceImpl;

public class CChubTenantServiceImpl {
    
}